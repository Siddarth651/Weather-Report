package com.example.openweatherupdatesapp.api

import com.example.openweatherupdatesapp.util.Constants.Companion.BASE_URL
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class RetrofitInstance {
    companion object{
     private val retrofit by lazy {
         val logging = HttpLoggingInterceptor().apply {
             level = HttpLoggingInterceptor.Level.BODY
         }
         val client = OkHttpClient.Builder()
              .addInterceptor(logging)
              .build()
         val gson1 = GsonBuilder()
             .setLenient()
             .create()
         Retrofit.Builder()
             .baseUrl(BASE_URL)
             .addConverterFactory(GsonConverterFactory.create(gson1))
             .client(client)
             .build()


     }
        val weatherApi by lazy {
            retrofit.create(WeatherApi::class.java)
        }
    }
}