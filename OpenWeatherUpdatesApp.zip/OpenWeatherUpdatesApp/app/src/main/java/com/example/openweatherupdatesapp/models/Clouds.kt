package com.example.openweatherupdatesapp.models

data class Clouds(
    val all: Int
)