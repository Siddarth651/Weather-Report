package com.example.openweatherupdatesapp.api

import com.example.openweatherupdatesapp.models.WeatherResponse
import com.example.openweatherupdatesapp.util.Constants.Companion.API_KEY

import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

// Weather API SAMPLE API URLS
// https://api.openweathermap.org/data/2.5/weather?q=New York&appid=API_KEY&units=metric
//https://api.openweathermap.org/data/2.5/weather?lat=44.34&lon=10.99&appid=API_KEY



interface WeatherApi {
    //Weather API Search API By CITY
    @GET("data/2.5/weather")
   suspend fun weatherByCity(
        @Query("q")
        searchString: String,
        @Query("appid")
        apiKey: String = API_KEY,
        @Query("units")
        units: String = "metric"
    ): Response<WeatherResponse>

    //Weather API Search API By Geographical Coordinates
    @GET("data/2.5/weather")
    suspend fun weatherByCoords(
        @Query("lat")
        latitude: Double,
        @Query("lon")
        longitude: Double,
        @Query("appid")
        apiKey: String = API_KEY,
        @Query("units")
        units: String = "metric"
    ): Response<WeatherResponse>





}