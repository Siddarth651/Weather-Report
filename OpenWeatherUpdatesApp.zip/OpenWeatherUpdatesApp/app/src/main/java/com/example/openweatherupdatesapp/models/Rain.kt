package com.example.openweatherupdatesapp.models

data class Rain(
    val `3h`: Double,
    val `1h`: Double
)