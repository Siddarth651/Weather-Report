package com.example.openweatherupdatesapp.util

import android.text.format.DateFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone


class Constants {
    companion object
    {

        val API_KEY = "03082a5fcd740651d15b170359808679"
        val BASE_URL = "https://api.openweathermap.org/"
        //weather icons base url
        val ICON_URL = "https://openweathermap.org/img/wn/"

        fun getDate(milliSeconds: Long, dateFormat: String?): String? {
            val formatter = SimpleDateFormat(dateFormat)
            val calendar: Calendar = Calendar.getInstance(TimeZone.getDefault(),Locale.getDefault())
            calendar.timeInMillis = milliSeconds*1000L
            return formatter.format(calendar.time)
        }
    }



}