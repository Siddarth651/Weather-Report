package com.example.openweatherupdatesapp.models

data class Coord(
    val lat: Double,
    val lon: Double
)