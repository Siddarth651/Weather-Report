package com.example.openweatherupdatesapp.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.SearchView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.core.location.LocationManagerCompat.isLocationEnabled
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.example.openweatherupdatesapp.databinding.ActivityWeatherBinding
import com.example.openweatherupdatesapp.models.WeatherResponse
import com.example.openweatherupdatesapp.repository.WeatherRepository
import com.example.openweatherupdatesapp.util.Constants.Companion.ICON_URL
import com.example.openweatherupdatesapp.util.Constants.Companion.getDate
import com.example.openweatherupdatesapp.util.Resource
import com.example.openweatherupdatesapp.viewmodel.WeatherViewModel
import com.example.openweatherupdatesapp.viewmodel.WeatherViewModelProviderFactory
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.gson.Gson
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class WeatherActivity : AppCompatActivity() {

    lateinit var binding: ActivityWeatherBinding
    lateinit var viewModel: WeatherViewModel
    private val PERMISSIONS = arrayOf(
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION"
    )
    val TAG = "WeatherActivity"
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var newQuery:String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWeatherBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.layoutMain.visibility = View.GONE
        val weatherRepository = WeatherRepository()
        val viewModelProviderFactory = WeatherViewModelProviderFactory(weatherRepository)
        viewModel = ViewModelProvider(this, viewModelProviderFactory)[WeatherViewModel::class.java]

        viewModel.weatherResultsByCity.observe(this, Observer { response ->
            when (response) {
                is Resource.Success -> {
                    response.data?.let { result ->

                        binding.apply {
                            layoutMain.visibility = View.VISIBLE
                            pbProgress.visibility = View.GONE
                            tvCityName.text = result.name
                            tvTempMain.text = "${result.main.temp}" + "\u2103"
                            tvMainDescription.text = "${result.weather[0].description}"
                            tvWeatherMain.text = "${result.weather[0].main}"
                            tvFeelsLike.text = "${result.main.feels_like}" + "\u2103"
                            tvPressure.text = "${result.main.pressure}"
                            tvHumidity.text = "${result.main.humidity}"
                            tvWind.text = "${result.wind.speed}"
                            val date = result.sys.sunrise.toLong()
                            val sunRise = getDate(date,"hh:mm:ss aa")
                            tvSunRise.text = " $sunRise"
                            tvSunSet.text = " ${getDate(result.sys.sunset.toLong(), "hh:mm:ss aa")}"

                            Glide.with(this@WeatherActivity)
                                .load(ICON_URL + "${result.weather[0].icon}@2x.png")
                                .into(imgTempIcon)
                        }
                    }

                }
                is Resource.Loading -> {
                    binding.pbProgress.visibility = View.VISIBLE

                }
                is Resource.Error -> {
                    binding.pbProgress.visibility = View.GONE
                    binding.layoutMain.visibility = View.GONE
                    Toast.makeText(this@WeatherActivity,"Error = ${response.message}",Toast.LENGTH_LONG).show()
                }
                else -> {
                    binding.pbProgress.visibility = View.GONE
                    binding.layoutMain.visibility = View.GONE
                }
            }


        })
        //1) Permission Check
        requestLocationPermission()

        //2)Search city by name or code or stateName or anything
        binding.etSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener,
            androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let {
                    if (query != newQuery) {
                        viewModel.getWeatherDataByCity(it)
                        newQuery = query
                    }
                    else
                    {
                        Toast.makeText(this@WeatherActivity,"Previous Query Contains Same CityName",Toast.LENGTH_LONG).show()
                    }
                }
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                //
                return false
            }
        })

        //onBackButtonPressedEvent

        //3) for auto loading saving last response in Preferences
        onBackPressedDispatcher.addCallback(this, object: OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val response = Gson().toJson(viewModel.weatherResponse)
                Log.e(TAG, "Bharath: ${response}" )
                if(response != null) {
                    Log.e(TAG, "handleOnBackPressed: $response")
                    val sharedPref = getPreferences(Context.MODE_PRIVATE) ?: return
                    with(sharedPref.edit()) {
                        putString("offLineData", response)
                        apply()
                        finish()
                    }
                }else
                {
                    finish()
                }



            }
        })






    }

    //4) Permission Handling for Location Acceess
    private fun requestLocationPermission() {
        if (!hasPermissions(*PERMISSIONS)) {
            showConsentPopup(876)
        } else {
            startLocationUpdates()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (!hasPermissions(*PERMISSIONS)) {
            //permission dialog
            showPermissionDialog()
        } else {
            //Processing for loaction updates
            startLocationUpdates()

        }
    }

    //if location accessible processing api calls
    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }
        if(isLocationEnabled()) {
            fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location ->
                    if (location == null) {
                        Log.e(TAG, "Failure Location")
                        //if location values are null load from offline data
                        loadOfflineData()
                    } else {
                        location?.let {
                            //weather using lat,lon
                            viewModel.getWeatherDataByLatLng(location.latitude, location.longitude)
                            Log.e(TAG, "Success Location")
                        }
                        //  loadOfflineData()

                    }

                    // Got last known location. In some rare situations this can be null.
                }
                .addOnFailureListener {
                    Log.e(TAG, "Failure Location ${it.message}")
                    loadOfflineData()

                }
        }else
        {
            Toast.makeText(this, "Please Enable Location to fetch Weather Report", Toast.LENGTH_LONG).show()
            openLocationSettings()
            loadOfflineData()
        }
    }

    //loading offline data from Shared Preference
    private fun loadOfflineData()
    {
        Log.e(TAG, "loadOfflineData: called " )
        viewModel.weatherResultsByCity.postValue(Resource.Loading())
        val sharedPref = getPreferences(Context.MODE_PRIVATE) ?: return
        val offLineResponseString = sharedPref.getString("offLineData",null)

        offLineResponseString?.let {
            val offLineData = Gson().fromJson(it,WeatherResponse::class.java)
            Log.e(TAG, "offLineResponseString:   $offLineData")
            offLineData?.let {
                viewModel.weatherResultsByCity.postValue(Resource.Success(offLineData))
                Toast.makeText(this,"Offline Data Loaded",Toast.LENGTH_LONG).show()

            }

        }


    }

//checking  for granted permissions
    private fun hasPermissions(vararg permissions: String?): Boolean {
        if (Build.VERSION.SDK_INT >= 23 && permissions != null) {
            for (permission in permissions) {
                if (ActivityCompat.checkSelfPermission(
                        this,
                        permission!!
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return false
                }
            }
        }
        return true
    }
    //used for launching a consent popup before of asking sensitive permission request
    private fun showConsentPopup(permCode: Int) {

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Consent Required")
        builder.setMessage("Please Allow access to Location Permission from Permission Dialogue")
        builder.setIcon(android.R.drawable.ic_dialog_alert)

        //performing positive action
        builder.setPositiveButton("Request") { dialogInterface, _ ->
            dialogInterface.dismiss()
            ActivityCompat.requestPermissions(
                this@WeatherActivity,
                PERMISSIONS, permCode
            )
        }
        //performing cancel action
        builder.setNeutralButton("Cancel") { dialogInterface, _ ->
            dialogInterface.dismiss()

        }

        builder.setNegativeButton("No") { dialogInterface, _ ->
            dialogInterface.dismiss()
        }
        val alertDialog: AlertDialog = builder.create()
        // Set other dialog properties
        alertDialog.show()
    }

    // if user denies any of the permission launching setting screen via pop-up
    private fun showPermissionDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Permissions Required")
        builder.setCancelable(false)
        builder.setMessage("Please allow these permissions in Application Settings under Permissions tab")
        builder.setPositiveButton(
            "Go to Settings"
        ) { dialog, which ->
            dialog.dismiss()
            goToSettings()
        }
        builder.setNegativeButton(
            "Cancel"
        ) { dialog, which -> dialog.dismiss() }
        builder.show()
    }

    //used for launching app level permission settings screen
    private fun goToSettings() {
        val myAppSettings = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse(
                "package:$packageName"
            )
        )
        myAppSettings.addCategory(Intent.CATEGORY_DEFAULT)
        myAppSettings.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(myAppSettings)
    }
    //used for launching Location Level setting screen
    private fun openLocationSettings() {
        val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
        startActivity(intent)
    }

    //checking whether loaction is accessable or not
    private fun isLocationEnabled(): Boolean {
        val locationManager: LocationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }



}

