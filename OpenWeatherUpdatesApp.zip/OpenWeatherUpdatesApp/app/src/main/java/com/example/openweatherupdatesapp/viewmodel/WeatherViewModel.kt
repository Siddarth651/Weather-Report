package com.example.openweatherupdatesapp.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.openweatherupdatesapp.models.WeatherResponse
import com.example.openweatherupdatesapp.repository.WeatherRepository
import com.example.openweatherupdatesapp.util.Resource
import kotlinx.coroutines.launch
import retrofit2.Response

class WeatherViewModel(
    val weatherRepository: WeatherRepository
) : ViewModel() {

    val weatherResultsByCity: MutableLiveData<Resource<WeatherResponse>> = MutableLiveData()

    var weatherResponse: WeatherResponse? = null

    init {
        //  getWeatherDataByCity("New York")
    }

    fun getWeatherDataByCity(cityName: String) = viewModelScope.launch {
        weatherResultsByCity.postValue(Resource.Loading())
        val response = weatherRepository.getWeatherByCity(cityName)
        weatherResultsByCity.postValue(processWeatherDataResponse(response))

    }


    fun getWeatherDataByLatLng(lat: Double, lon: Double) = viewModelScope.launch {
        weatherResultsByCity.postValue(Resource.Loading())
        val response = weatherRepository.getWeatherByCoords(lat, lon)
        weatherResultsByCity.postValue(processWeatherDataResponse(response))

    }


    private fun processWeatherDataResponse(response: Response<WeatherResponse>): Resource<WeatherResponse> {
        if (response.isSuccessful) {
            response.body()?.let { resultResponse ->
                weatherResponse = resultResponse
                return Resource.Success(resultResponse)
            }
        }
        return Resource.Error(response.message())
    }

}
