package com.example.openweatherupdatesapp.models

data class Sys(
    val country: String,
    val sunrise: Long,
    val sunset: Long,
    val pod: String
)