package com.example.openweatherupdatesapp.models

data class Wind(
    val deg: Double,
    val gust: Double,
    val speed: Double
)