package com.example.openweatherupdatesapp.repository

import com.example.openweatherupdatesapp.api.RetrofitInstance

class WeatherRepository {
    suspend fun getWeatherByCity(cityName : String) =
        RetrofitInstance.weatherApi.weatherByCity(cityName)

    suspend fun getWeatherByCoords(lat : Double, long : Double) =
        RetrofitInstance.weatherApi.weatherByCoords(lat,long)

}